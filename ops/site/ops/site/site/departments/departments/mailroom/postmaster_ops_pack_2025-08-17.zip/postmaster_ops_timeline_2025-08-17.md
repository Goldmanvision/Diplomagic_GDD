---
Title: Postmaster Operations Timeline
Department: Mail
Codename: Postmaster
Date: 2025-08-17
Audience: Publishing (Suit), All Leads
---

# Timeline

- Setup: Departments roster + macros; chat rename standard prepared.
- Notices: Corkboard — Canvas Audit and Chat Alignment posted.
- A&R: created refs_seed_1994.md (×5), checks core terms batches 1–3, glossary batches 1–3.
- Narrative: mirrored Playbook and Outline; added source metadata.
- Steam Ops: charter + dashboard stubs.
- Adversary: dashboard; statblock schema; 4 statblocks; spawn table; archived two legacy docs and created stubs.
- QA & UX: dashboard.
- ASCII-safe: generated duplicate tree; mapping; plan; applied renames and internal link fixes; verification branch clean outside Archive/Backups.
