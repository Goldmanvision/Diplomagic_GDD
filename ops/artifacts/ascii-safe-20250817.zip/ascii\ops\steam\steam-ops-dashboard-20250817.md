
## Keep
- steam_ops_charter_20250817.md
- steam_ops_dashboard_20250817.md

## Milestones
- Store page draft — TBD
- First build upload — TBD
- Coming soon publish — TBD

## Today
- Collect asset inventory and owners.

## Next 7 days
- Define depot/branch map.
- Draft store assets checklist.

## Risks
- Missing asset resolutions or sizes.
- Build pipeline undefined.

## Links
- research/refs/refs_seed_1994.md
- narrative/playbook.md
- narrative/outline_2025.md

Last updated: 2025-08-17
