---
Department: Narrative & Canon
Codename: Storymaster
Type: Mirror
Source: /mnt/data/DIPLOMAGIC Narrative Playbook.pdf
Last-Mirrored: 2025-08-17
Source-Bytes: 116849
Source-MD5: 9113b6fec1dacb9736df15106c209e28
Source-Pages: 25
Edit Policy: Do not edit. Update the source PDF.
---


# Mirror Index
Canonical source stored as PDF. This mirror tracks metadata, placement, and cross-links only.

## Cross-links
- Authenticity & Research: research/refs/refs_seed_1994.md
- Authenticity & Research: research/checks/period_check_core_terms_1994.md
- Authenticity & Research: research/glossary_1994.md

## Change log
- 2025-08-17: Metadata refresh.
