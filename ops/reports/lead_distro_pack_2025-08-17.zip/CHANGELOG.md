# CHANGELOG

## 2025-08-17
Created
- /narrative_scene_ids_prologue_ch1.md  (Batch 1; canonical target: /narrative/scenes/scene_ids_prologue_ch1.md)

Updated
- /narrative/reports/ch1_pacing_vs_spawns_20250819.md  (added SG-20250817 rationale and refs)
- /ops/steam/depot_branch_map_20250819.md  (Plan A OS targets; Proton QA tag)
- /ops/steam/store_asset_checklist_20250819.md  (Plan A targets; dims TODO and crop notes)
- /research/refs/refs_seed_1994.md  (URLs required flags; scans paths)
