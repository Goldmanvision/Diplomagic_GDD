# DECISIONS

## 2025-08-17
- Approved: Spectral Gating Rule **SG-20250817**.
- Approved: OS Targets **Plan A** — Windows 10/11 x64 + Steam Deck via Proton; Linux/macOS post‑freeze.
- Canonical scene IDs registry to live at `/narrative/scenes/scene_ids_prologue_ch1.md` (rename from root copy on commit).
- Postmaster to route handoffs; Double‑Confirm on multi‑file batches remains in effect.
