# Naming and Thread Topology

## Project name
DIPLOMAGIC GDD

## Office chat title template
`<Department> :: <Team Name> - Ops Thread <N>`

## Rollover naming
Main project chat title:
`GDD Rebuild <YYYY-MM-DD HHmm ET>` in America/New_York.

## Canonical department list
- Mail :: Integration & Validation — codename Postmaster
- Steam Operations — codename Stationmaster
- QA / UX — codename Exterminator
- Combat & Systems — codename Armorer
- Authenticity & Research — codename Archivist
- Narrative & Canon — codename Storymaster
- Publishing Studio — codename The Suit
- Adversary & NPC Systems — codename Taxonomist
- Macro Managers — Tech Support — nickname McMa
