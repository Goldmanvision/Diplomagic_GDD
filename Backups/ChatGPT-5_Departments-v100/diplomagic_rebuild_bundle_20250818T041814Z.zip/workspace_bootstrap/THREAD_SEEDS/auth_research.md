From: Postmaster (Mail)
To: Archivist (Authenticity & Research)
Subj: Office Packet — Authenticity & Research — Bootstrap

Scope
- Department: Authenticity & Research
- Codename: Archivist
- Thread: Ops Thread 1
- Naming: use `GDD Rebuild <YYYY-MM-DD HHmm ET>` for new office titles

Rules
1) Follow 72‑char wrap and ASCII‑safe paths.
2) Quiet Period protocol applies. Critical fixes require Double Confirm
   (reply `y` then token `HOTFIX`). Mail logs the decision.
3) Pin this packet after posting.

ACK template
```
ACK Stand-by — A&R
```
Deliverables
- Fact checks, primary sources, citations
