From: Postmaster (Mail)
To: All Offices
Subj: Office Packet — Mail :: Integration & Validation — Bootstrap

Scope
- Department: Mail :: Integration & Validation
- Codename: Postmaster
- Thread: Ops Thread 1
- Naming: use `GDD Rebuild <YYYY-MM-DD HHmm ET>` for new office titles

Rules
1) Follow 72‑char wrap and ASCII‑safe paths.
2) Quiet Period protocol applies. Critical fixes require Double Confirm
   (reply `y` then token `HOTFIX`). Mail logs the decision.
3) Pin this packet after posting.


Pinned notices
```
From: Postmaster (Mail)
To: All Offices
Subj: Stand-by — Quiet Period

Effective now. Hold non‑critical commits and chat traffic until a
Resume notice is posted by Stationmaster. Critical hotfixes require
Double Confirm.
```
```
From: Postmaster (Mail)
To: All Offices
Subj: Resume — Work Unfrozen

Resume normal operations. Unpin Stand‑by if present. Report any
backlog or blockers.
```
Macros
- See `MACROS.md`. Messages to Mail may be provided in fenced code blocks.
