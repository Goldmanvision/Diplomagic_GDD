# Macro Manifest v0.1

## Zero‑arg tokens
- `ptstamp` ⇒ returns: `GDD Rebuild <YYYY-MM-DD HHmm ET>` using America/New_York.
- `deptcode` ⇒ returns exactly:
  Department: Mail
  Codename: Postmaster.
- `mydept` ⇒ returns: `<Department> : <Codename>` for the current chat context;
  if unset, returns `Unknown : Unknown.`

## Mail templates
- `mail-template: From | To | Subj | Body`
  Renders a standard header block with 72‑char wrap.
- `handoff-checklist: Department | Work item`
  Emits a checklist with owner, inputs, outputs, due date.
- `decision-entry: YYYY-MM-DD | Title | Status | Owner= | Logged=`
  Appends a one‑line decision log item.
- `changelog-entry: YYYY-MM-DD | Area | Change | Scope=`
  Appends a one‑line change log item.

## Content templates
- `scene-spec: SceneID | Location | Cast | Beats`
- `dialogue-page: SceneID | Speaker | Style`
- `enemy-statblock: Name | Tier | HP | Attacks | Notes`
- `spawn-row: Level | Biome | Rate | Constraints`
- `bug-card: ID | Title | Severity | Repro | Expected | Actual`
- `store-copy: Tagline | Short | Long`

Implementation note: macros are simple text expanders. Keep outputs ASCII‑safe and line‑wrapped to 72.
