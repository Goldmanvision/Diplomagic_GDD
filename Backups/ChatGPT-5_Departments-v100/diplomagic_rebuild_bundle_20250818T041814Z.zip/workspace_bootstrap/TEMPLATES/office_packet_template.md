From: Postmaster (Mail)
To: <Department>
Subj: Office Packet — <Department Name> — Bootstrap

Scope
- Department: <name>
- Codename: <codename>
- Thread: Ops Thread 1

Rules
- 72‑char wrap. ASCII‑safe paths.
- Quiet Period protocol. Double Confirm for hotfixes.
- Pin this packet.
