# Exact Reproduction Guide — For Nick's father (ChatGPT‑5)

Goal: recreate Nick’s DIPLOMAGIC Project Workspace so responses and behavior match.

## What you need
- Access to ChatGPT‑5.
- Nick’s ZIP backup and GitHub repo URL.
- This folder: `workspace_bootstrap/`.

## 15‑minute procedure
1) Create a new Project Workspace named **DIPLOMAGIC GDD**.
2) Open its **Instructions** panel. Copy‑paste the full text from `INSTRUCTIONS.md`.
3) Create chats for each department in this order:
   - Mail :: Integration & Validation — Ops Thread 1
   - Steam Operations — Ops Thread 1
   - QA / UX — Ops Thread 1
   - Combat & Systems — Ops Thread 1
   - Authenticity & Research — Ops Thread 1
   - Narrative & Canon — Ops Thread 1
   - Publishing Studio — Ops Thread 1
   - Adversary & NPC Systems — Ops Thread 1
4) For each chat, open the matching file in `THREAD_SEEDS/` and paste it as the
   first message. Pin it.
5) Open a new **Admin** chat. Paste `MEMORY.md` as the first message. Pin it.
6) In the Mail chat, post the Stand‑by notice from the Mail seed. Confirm each
   department replies ACK. Then post Resume.
7) On your computer, unzip Nick’s ZIP to a folder. If using Git, run:
   ```bash
   git clone <NickRepoURL> DIPLOMAGIC_GDD
   # or add the remote inside the unzipped folder
   ```
8) Optional: run the snapshot scripts in `diplomagic_backup_kit/` to create a
   fresh backup on your machine.
9) Validate with the checklist in `CHECKLISTS/VALIDATION.md`.

Notes: There is no import for historical chats. The seeds give each department its
scope and behavior so future outputs align with Nick’s setup.
