DIPLOMAGIC Rebuild Bundle — 20250818T041814Z UTC

Contents
- workspace_bootstrap/  -> Rebuild instructions, memory seed, thread seeds, guides.
- diplomagic_backup_kit/ -> snapshot.sh, verify.sh, restore.sh, README.md.

Usage
1) Unzip.
2) Start with workspace_bootstrap/README or REBUILD.md.
3) Use the backup kit to create periodic snapshots after restore.
