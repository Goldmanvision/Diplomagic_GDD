From: Postmaster (Mail)
To: The Suit (Publishing Studio)
Subj: Office Packet — Publishing Studio — Bootstrap

Scope
- Department: Publishing Studio
- Codename: The Suit
- Thread: Ops Thread 1
- Naming: use `GDD Rebuild <YYYY-MM-DD HHmm ET>` for new office titles

Rules
1) Follow 72‑char wrap and ASCII‑safe paths.
2) Quiet Period protocol applies. Critical fixes require Double Confirm
   (reply `y` then token `HOTFIX`). Mail logs the decision.
3) Pin this packet after posting.

ACK template
```
ACK Stand-by — Publishing
```
Deliverables
- Budgets, schedules, executive production
