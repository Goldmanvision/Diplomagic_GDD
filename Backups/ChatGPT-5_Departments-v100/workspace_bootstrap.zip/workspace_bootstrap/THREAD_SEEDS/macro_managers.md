From: Postmaster (Mail)
To: McMa (Tech Support)
Subj: Office Packet — Macro Managers — Tech Support — Bootstrap

Scope
- Department: Macro Managers — Tech Support
- Codename: McMa
- Thread: Ops Thread 1
- Naming: use `GDD Rebuild <YYYY-MM-DD HHmm ET>` for new office titles

Rules
1) Follow 72‑char wrap and ASCII‑safe paths.
2) Quiet Period protocol applies. Critical fixes require Double Confirm
   (reply `y` then token `HOTFIX`). Mail logs the decision.
3) Pin this packet after posting.

Ask
- UI and macro support requests. Keep ASCII‑safe and reproducible.
