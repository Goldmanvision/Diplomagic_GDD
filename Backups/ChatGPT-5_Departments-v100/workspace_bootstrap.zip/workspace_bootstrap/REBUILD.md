# Rebuild Runbook — DIPLOMAGIC Workspace

## Inputs
- Your ZIP backup of files.
- GitHub repo (remote + tokens managed by you).
- This `workspace_bootstrap/` folder.

## Steps
1. Create a new Project Workspace named **DIPLOMAGIC GDD**.
2. Open Instructions. Paste `INSTRUCTIONS.md` verbatim.
3. Restore files from ZIP to a local folder. `git remote add` your repo and pull.
4. Create department chats using `NAMING.md` topology.
5. For each department, open `THREAD_SEEDS/<dept>.md`. Paste the whole seed
   as the first message and pin it.
6. Open an internal **Admin** thread. Paste `MEMORY.md`. Pin it.
7. Recreate automations from `AUTOMATIONS.md`.
8. Upload any canvas exports you want versioned, and link them in the relevant
   department headers.
9. Smoke test: in Mail, post Stand‑by, collect ACKs, then post Resume.
10. Commit `workspace_bootstrap/` to the repo. Tag `bootstrap-<date>`.
