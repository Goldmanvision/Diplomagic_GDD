# Automations Inventory (template)

- Daily 09:00 ET — Search for "stand-by pending" in Mail and notify me if present.
  Prompt: "Search for stand-by notices older than 24h and notify me if so."
- Weekly Mon 10:00 ET — Snapshot script run confirmation.
  Prompt: "Tell me to run snapshot.sh for DIPLOMAGIC_GDD and verify manifest."
- Release days — 2h pre-deadline — Checklist ping.
  Prompt: "Tell me to post handoff-checklist to all offices."

Record automations here with schedule, prompt text, and owner.
