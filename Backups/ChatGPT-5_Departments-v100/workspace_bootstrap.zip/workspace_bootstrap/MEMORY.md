# Long‑lived Memory Seed

- Project: DIPLOMAGIC.
- Dual protagonists: Clara Winston (analogue), Avery Jordan (FBI procedural, 1994).
- Structure: Prologue, Chapters 1–6, Epilogue, multi‑ending design.
- UI motif: IBM Simon / Palm Pilot / Newton.
- Visual style: PS1‑era 3D + modern VFX.
- Constraints: ASCII‑safe paths; 72‑char wrap in mail; 1994/1989 accuracy.
- Departments → Codenames:
  - Mail: Postmaster.
  - Steam Operations: Stationmaster (user lead).
  - QA & UX: Exterminator.
  - Combat & Systems: Armorer.
  - Authenticity & Research: Archivist.
  - Narrative & Canon: Storymaster.
  - Publishing Studio: The Suit.
  - Adversary & NPC Systems: Taxonomist.
- Stand‑by protocol and Double Confirm for hotfixes.
- Naming: `GDD Rebuild <YYYY-MM-DD HHmm ET>` (America/New_York).
- Messages to Postmaster should be fenced code blocks.
