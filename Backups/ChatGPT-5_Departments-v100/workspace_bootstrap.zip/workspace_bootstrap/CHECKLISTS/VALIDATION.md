# Validation Checklist

- [ ] Instructions pasted and pinned.
- [ ] Admin thread created and MEMORY seeded.
- [ ] All department threads created and seeded.
- [ ] Stand‑by → ACKs → Resume round-trip successful.
- [ ] Macro tokens `ptstamp`, `deptcode`, `mydept` respond as defined.
- [ ] Naming template visible in new thread titles.
- [ ] Snapshot scripts tested (one snapshot present).
- [ ] Repo linked and clean pull succeeded.
