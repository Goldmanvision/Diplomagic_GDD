# DIPLOMAGIC GDD

This site hosts the GDD.
