# PRD — GDD Dashboard

## Goal
Single UI in MkDocs to view ptcorks and copy prompts per department.

## Users
Producer (solo). Dept leads.

## Scope (MVP)
- Tabs: Mail, Publishing, Narrative, Combat/Systems, Auth/Rec, Steam Ops, QA/UX, Tech Support.
- One prompt textarea per tab with Copy button.
- Static ptcorks pages per dept in `docs/depts/<dept>/ptcorks.md`.

## Out of scope
Agent responses rendering; auth; search.

## Non-functional
Local build via `mkdocs serve`. No CI build in this PR.

## Acceptance
Tabs render. Copy works. Adding a new `depts/<dept>/prompt.txt` shows on the tab.
