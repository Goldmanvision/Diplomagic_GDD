function copyPrompt(id){
  const el = document.getElementById(id);
  if(!el) return;
  const text = el.value || el.textContent || "";
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).catch(() => {
      el.select(); document.execCommand('copy');
    });
  } else {
    el.select(); document.execCommand('copy');
  }
}
