# GDD Dashboard

=== "Postmaster :: Mail"
<textarea id="postmaster-prompt" rows="8" style="width:100%">
--8<-- "depts/postmaster/prompt.txt"
</textarea>
<button onclick="copyPrompt('postmaster-prompt')">Copy prompt</button>
[View ptcorks](depts/postmaster/ptcorks.md)

=== "The Suit :: Publishing"
<textarea id="suit-prompt" rows="8" style="width:100%">
--8<-- "depts/suit/prompt.txt"
</textarea>
<button onclick="copyPrompt('suit-prompt')">Copy prompt</button>
[View ptcorks](depts/suit/ptcorks.md)

=== "Storymaster :: Narrative / Canon"
<textarea id="storymaster-prompt" rows="8" style="width:100%">
--8<-- "depts/storymaster/prompt.txt"
</textarea>
<button onclick="copyPrompt('storymaster-prompt')">Copy prompt</button>
[View ptcorks](depts/storymaster/ptcorks.md)

=== "Armorer :: System / Combat"
<textarea id="armorer-prompt" rows="8" style="width:100%">
--8<-- "depts/armorer/prompt.txt"
</textarea>
<button onclick="copyPrompt('armorer-prompt')">Copy prompt</button>
[View ptcorks](depts/armorer/ptcorks.md)

=== "Archivist :: Auth / Rec"
<textarea id="archivist-prompt" rows="8" style="width:100%">
--8<-- "depts/archivist/prompt.txt"
</textarea>
<button onclick="copyPrompt('archivist-prompt')">Copy prompt</button>
[View ptcorks](depts/archivist/ptcorks.md)

=== "Stationmaster :: Steam Operations"
<textarea id="stationmaster-prompt" rows="8" style="width:100%">
--8<-- "depts/stationmaster/prompt.txt"
</textarea>
<button onclick="copyPrompt('stationmaster-prompt')">Copy prompt</button>
[View ptcorks](depts/stationmaster/ptcorks.md)

=== "Exterminator :: QA / UX"
<textarea id="exterminator-prompt" rows="8" style="width:100%">
--8<-- "depts/exterminator/prompt.txt"
</textarea>
<button onclick="copyPrompt('exterminator-prompt')">Copy prompt</button>
[View ptcorks](depts/exterminator/ptcorks.md)

=== "Macro Manager :: Tech Support"
<textarea id="macromanager-prompt" rows="8" style="width:100%">
--8<-- "depts/macromanager/prompt.txt"
</textarea>
<button onclick="copyPrompt('macromanager-prompt')">Copy prompt</button>
[View ptcorks](depts/macromanager/ptcorks.md)
