# DIPLOMAGIC GDD

Use the Dashboard tab for dept prompts and ptcorks.
