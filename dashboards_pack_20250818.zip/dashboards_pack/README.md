# dashboards_pack
Place these under your repo path: `/departments/<dept>/Dashboard.md`.

## MkDocs nav snippet
```yaml
nav:
  - Dashboards:
      - Narrative: departments/narrative/Dashboard.md
      - Combat & Systems: departments/combat_systems/Dashboard.md
      - Statblocks & Enemies: departments/statblocks_enemies/Dashboard.md
      - Authenticity & Research: departments/authenticity_research/Dashboard.md
      - QA & UX: departments/qa_ux/Dashboard.md
      - Steam Operations: departments/steam_ops/Dashboard.md
      - Builds: departments/builds/Dashboard.md
      - Mail: departments/mail/Dashboard.md
      - Risk: departments/risk/Dashboard.md
      - Brainstorming: departments/brainstorming/Dashboard.md
```

## Update protocol
- Departments submit PRs updating their Dashboard.md.
- Stationmaster reviews and merges. Mail logs DECISIONS/CHANGELOG when needed.
- Keep updates small and frequent.
