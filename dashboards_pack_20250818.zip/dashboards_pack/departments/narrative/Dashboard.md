# Narrative — Dashboard
Owner: <handle>  |  Updated: 2025-08-18  |  SLA: <n>d  |  Gates: <list>

## Status
- Health: Green|Yellow|Red
- Risks: <short list>
- Next deliverables: <bullets with due dates>

## Workboard
| ID | Title | Status | Priority | Due | Link |
|----|-------|--------|----------|-----|------|
|    |       |        |          |     |      |

## Handoffs
- Outbound: <to dept> → <artifact> → <link>
- Inbound: <from dept> → <need> → <link>

## Sources
- Charter: /department_charters_pack.md
- Specs: /departments/narrative/
- Tests: /qa/plans/

Notes: Link scene specs and dialogue under /narrative/. Ensure 1994/1989 period checks.
