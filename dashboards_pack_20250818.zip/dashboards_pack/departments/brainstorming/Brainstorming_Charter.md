# Brainstorming Department — Charter
Purpose: Isolated ideation. No merges to production folders. Interacts only with Stationmaster.

Scope
- Location: /departments/brainstorming/
- Output: proposals, risk/benefit notes, wireframes, sandboxes
- Branching: brain/<topic>/*

Rules
1) No cross-dept handoffs. Mail only logs approved decisions.
2) PRs labeled `brainstorm`. Owner: Stationmaster.
3) 1994/1989 accuracy remains required when proposing player-facing content.
4) ASCII-safe paths. No binary blobs; link external references.

Dashboard fields
- Idea queue with Impact, Effort, Risk, 1994/1989 fit scores.
- Decision ledger linking to DECISIONS.md entries.

Updated: 2025-08-18
