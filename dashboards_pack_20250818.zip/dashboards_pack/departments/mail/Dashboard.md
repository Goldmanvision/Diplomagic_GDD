# Mail — Dashboard
Owner: <handle>  |  Updated: 2025-08-18  |  SLA: <n>d  |  Gates: <list>

## Status
- Health: Green|Yellow|Red
- Risks: <short list>
- Next deliverables: <bullets with due dates>

## Workboard
| ID | Title | Status | Priority | Due | Link |
|----|-------|--------|----------|-----|------|
|    |       |        |          |     |      |

## Handoffs
- Outbound: <to dept> → <artifact> → <link>
- Inbound: <from dept> → <need> → <link>

## Sources
- Charter: /department_charters_pack.md
- Specs: /departments/mail/
- Tests: /qa/plans/

Notes: Surface DECISIONS/CHANGELOG excerpts and current notices.
