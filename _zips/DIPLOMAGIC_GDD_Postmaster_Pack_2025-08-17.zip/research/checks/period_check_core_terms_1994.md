---
Department: Authenticity & Research
Codename: Archivist
Date: 2025-08-17
Type: Checklist
Status: Draft
---

# Period Check — Core Terms 1994
Purpose: define and constrain terminology to 1994 usage for DIPLOMAGIC.

Sections
- Media and tech terms
- Law enforcement procedures and jargon
- Pop culture references
- Communications slang
- Forbidden anachronisms

Review cadence: per chapter milestone.
