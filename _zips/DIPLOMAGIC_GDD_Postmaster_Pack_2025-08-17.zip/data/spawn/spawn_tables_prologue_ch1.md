---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: SpawnTable
Status: Stub
---

# Spawn Tables — Prologue + Chapter 1
Placeholder stub. Link to statblocks with canonical IDs.
