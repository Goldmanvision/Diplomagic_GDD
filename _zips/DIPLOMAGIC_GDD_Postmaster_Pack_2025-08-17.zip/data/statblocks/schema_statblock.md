---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: Schema
Status: Stub
---

# Schema Statblock
Placeholder stub. Populate per schema_statblock.md.
