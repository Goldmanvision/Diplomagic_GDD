---
Department: Narrative & Canon
Codename: Storymaster
Date: 2025-08-17
Type: Mirror
Source: /mnt/data/DIPLOMAGIC Narrative Playbook.pdf
Edit Policy: Do not edit. Update the source PDF.
Status: Mirrored
---

# DIPLOMAGIC Narrative Playbook — Mirror
This file indexes the canonical PDF and tracks placement only.
