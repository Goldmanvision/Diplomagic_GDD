# Tracker — Metrics Snapshot Template (CH5–CH6)
Repo dir: /Trackers
Date: 2025-08-15

## Summary
Quick text snapshot for standups.

| KPI | Value |
|---|---|
| Time CH5 start → CH6 Vault |  |
| CH6 Ending mix (A/B/C) |  |
| Avg EvidenceCount (0–3) |  |
| BlueOnBlue incidents |  |
| Avg deaths |  |
| Ammo spent P/S/R |  |
| Tonics used |  |
| Peak Fear state |  |

## Notes
- 1994 lock. Prompts ≤14. Ambient phrase only: “the stars are right tonight.”
- Source logs: `/Trackers/CH6_Balance_Telemetry_Spec.md`, `/Trackers/CH6_Playtest_Log_Sheet.md`.
