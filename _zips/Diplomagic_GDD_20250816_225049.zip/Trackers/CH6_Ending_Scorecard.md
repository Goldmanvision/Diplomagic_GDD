# Tracker — CH6 Ending Scorecard
Repo dir: /Trackers

## Run meta
- Build: ______
- Difficulty: ______
- DeputyName: ______
- Path: Contain / Sever / Black File

## Counters
- EvidenceCount (0–3): ____
- BlueOnBlue (0/1): ____
- Photos: ____
- Samples: ____

## Scores
- Ending bonus:  +5 (Contain) | +3 (Sever) | +5 (Black File)
- Evidence:      +2 × EvidenceCount  (cap 3)
- Reputation:    −5 if Black File
- Blue‑on‑Blue:  FAIL (−10, abort) if set

## Computed
- FinalScoreDelta: ______
- RepDelta: ______

## Notes
- Neutralizations are score‑neutral under CH6 raid ROE.
- Phrase remains ambient only: “the stars are right tonight.”
