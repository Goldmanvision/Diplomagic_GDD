## UI — CH3 Prompts (SEC-07 addendum)

### Clara/Reddy (≤14 chars)
Grab, Throw, Drop, Pin, Stack, Block, Shield, Swap, Soothe, Rest, Use, Inspect, Map, Note

### Avery (≤14 chars)
Holster, Reload, Sprint, Duck, Vault, Search, Bag, Tag, Radio, Map, Aim, Fire, Phase, Swap
