# ROOT_SEC-07_UI_Prompts_CH7_Extensions.md
> Add to the prompts master. All ≤14 chars.

## City
- Restrain
- Tase
- Escort
- Payphone
- Dial
- Hang Up
- Page
- Fax Send
- Consent
- Warrant
- Decoy
- Subdue

## Mindscape
- Anchor
- Counter
- Dispel
- Reveal
- Focus
- Ground
- Wake
- Retreat
