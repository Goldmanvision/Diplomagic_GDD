# Root Merge — Done Checklist (CH5–CH6)
Repo dir: /Patches

- [ ] CH5 pasted into `SEC-03-NARRATIVE - Narrative.md`
- [ ] CH6 pasted into `SEC-03-NARRATIVE - Narrative.md`
- [ ] Systems appended in `SEC-05-SYSTEMS - Systems & Mechanics.md`
- [ ] World/UI appended in `SEC-06-WORLD` and `SEC-07-UI`
- [ ] README/ToC updated
- [ ] Validation grep/rg run
- [ ] Build verification checklist completed
- [ ] PR opened and reviewers assigned
- [ ] Tag created after merge
