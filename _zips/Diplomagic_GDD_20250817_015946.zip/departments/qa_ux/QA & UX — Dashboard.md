---
Department: QA & UX
Codename: Exterminator
Date: 2025-08-17
Type: Dashboard
Status: Active
---

# QA & UX — Dashboard

Keep
- TBD

Pipelines
- Playtest build verification
- Usability test scripts

Notes
- Export all reports as .md
