ARCHIVE PACK — Epilogue CI Assertions

PR URL:
- ci/epilogue-asserts: https://github.com/Goldmanvision/Diplomagic_GDD/compare/main...ci/epilogue-asserts

SHAs:
- ci/epilogue-asserts = d12827c48d0225b1f40bc8f0e8ae7ae4f8715c9e
