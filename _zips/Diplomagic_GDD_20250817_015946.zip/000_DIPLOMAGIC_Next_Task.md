Project: DIPLOMAGIC — Narrative Review + GDD Patches
Repo: Goldmanvision/Diplomagic_GDD (Git is source of truth)
Task: Resume CH1 narrative corrections. Use scene IDs A1–A5, B1–B4. Apply fixes to trackers and prepare SEC-03 §3.5 updates if needed. Keep prompts ≤14 chars, period-accurate 1994. Maintain ≤5 canvases. Warn before heavy ops. Commit summaries <50 chars.
