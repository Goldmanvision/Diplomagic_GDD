﻿v0.1-docs-structure — 2025-08-16

- Added structured narrative playbook and packaging sync.
- Included initial CHANGELOG.md and documentation for Steam prep.
- Fixed documentation layout and created baseline tags for release management.
- Added exported chat archives in /Archive for provenance and traceability.
- Notes: Compliance fixes for CH2 merged; follow-up QA required for CH6/CH7 evidence-cap validations.
