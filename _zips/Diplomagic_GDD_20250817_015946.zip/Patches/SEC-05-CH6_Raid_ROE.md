# SEC-05 — CH6 Raid ROE One-Pager
Repo dir: /Patches

## Authorization
- Target: Hostile combatants of the Sovereign Nation of New Kadath / Order of the Splintered God.
- Lethal force authorized. No Final Score penalty for lethal.

## Restrictions
- Blue-on-blue / friendly-fire: hard fail (−10 and abort).  
- No civilians in AO. If encountered by design change, disengage and mark.

## Evidence
- Bonus +2 per item, **cap 3** for CH6 total.

## Comms
- Rogue posture. Krill via pager/payphone only.

## UI
Aim, Fire, Reload, Suppress, Frag, Equip L, Equip R, Cast L, Cast R, Shield, Ward Jam, Map, Note
