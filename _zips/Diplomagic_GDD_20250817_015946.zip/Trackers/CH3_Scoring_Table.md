# Tracker — CH3 Scoring Table
Version: v0.1 • 2025-08-15

## Clara & Reddy
| Action | Points |
|---|---:|
| Non-lethal TK disable | +3 |
| Protective block (save Clara) | +2 |
| Evidence page logged | +1 |
| Wanton TK destruction | −3 |
| Alert escalation | −2 |

## Avery
| Action | Points |
|---|---:|
| Evidence secured (each) | +2 |
| Escape without civilian harm | +3 |
| Civilian endangered | −3 |
| Spectral killed with phased gear | 0 |
| Reached Panicked Fear state | −1 (cap −3) |
