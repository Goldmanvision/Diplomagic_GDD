# Tracker — 1994 Glossary (CH5–CH6)
Repo dir: /Trackers

- **ASAC:** Assistant Special Agent in Charge.  
- **BOLO:** Be On the Lookout teletype.  
- **FD‑302:** Interview/incident form.  
- **MicroTAC:** Motorola flip phone model line (pre‑StarTAC).  
- **Pager:** Numeric; code messages only.  
- **Payphone:** Coin phone; limit calls ≤90 s.  
- **SENTINEL:** Agency system; NYFO terminals only.  
- **TAPLINE:** Evidence upload queue; secure line only.  
- **UC:** Undercover operation.  
- **Polaroid:** Instant photo used for valve tags and evidence.  
- **Analog CCTV:** Tape‑based, no network.
