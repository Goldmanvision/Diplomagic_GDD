---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Status: Archived
Superseded-By: Adversary & NPC Systems — Dashboard + schema_statblock.md
---

# Enemy Systems Department — notes (Archived)
Archived per Postmaster directive. Do not edit. Keep for provenance.
