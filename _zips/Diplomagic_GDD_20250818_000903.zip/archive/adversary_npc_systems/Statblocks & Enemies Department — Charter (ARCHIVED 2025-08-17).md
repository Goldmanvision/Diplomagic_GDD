---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Status: Archived
Superseded-By: Adversary & NPC Systems — Dashboard + schema_statblock.md
---

# Statblocks & Enemies Department — Charter (Archived)
Archived per Postmaster directive. Do not edit. Keep for provenance.
