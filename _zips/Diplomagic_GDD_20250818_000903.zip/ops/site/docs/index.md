---
title: Workspace Home
---

# DIPLOMAGIC Workspace

This local site mirrors selected Markdown from the repo for quick navigation.

- Edit files in the repo. Run the sync script to update this site.
- All paths are ASCII-safe. Keep filenames kebab-case.
- Freeze track: target narrative freeze 2025-08-24.

_Last updated: 2025-08-17_
