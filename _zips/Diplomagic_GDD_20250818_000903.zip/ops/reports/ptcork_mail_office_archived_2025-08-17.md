ptcork v2
title: Mail office archived — continue in Ops Thread 2
channel: #ops
content: This Mail chat is archived. All routing continues in “Postmaster — Ops Thread 2.” Logs and handoffs unchanged.
link: /DECISIONS.md
---
