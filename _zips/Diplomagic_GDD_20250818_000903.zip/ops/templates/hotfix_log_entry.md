### 2025-08-17 hotfix_authorized_<DeptSlug>
decision: HOTFIX approved during Stand-by.
context: <reason>
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: <Dept>
files:
  - <list>
rollback_plan: <summary>
