Msg received

From: <Requester>
To: Postmaster (Mail)
Subj: HOTFIX Request — <Dept> — <YYYY-MM-DD>

<Owner>::<Dept> - <Office>

Impact
- <build blocking | data loss | security | store deadline>

Files
- <list>

Rollback
- Plan: <steps>

Confirm
- Reply "y" then token HOTFIX to authorize.
