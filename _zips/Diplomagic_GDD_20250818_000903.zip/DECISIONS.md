<<<<<<< HEAD
### 2025-08-17 standby_quiet_period_ack_A_R
decision: A&R acknowledged Stand-by order.
context: Quiet Period active; pins require lead UI action.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: A&R
files:
  - ops/reports/standby_ack_Authenticity___Research_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_QA___UX
decision: QA & UX acknowledged Stand-by order.
context: Quiet Period active; notice pinned; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: QA & UX
files:
  - ops/reports/standby_ack_QA___UX_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_Mail
decision: Mail acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Mail
files:
  - ops/reports/standby_ack_Mail_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_Steam_Operations
decision: Steam Operations acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Steam_Operations
files:
  - ops/reports/standby_ack_Steam_Operations_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_Narrative___Canon
decision: Narrative   Canon acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Narrative & Canon
files:
  - ops/reports/standby_ack_Narrative___Canon_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_Adversary___NPC_Systems
decision: Adversary   NPC Systems acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Adversary & NPC_Systems
files:
  - ops/reports/standby_ack_Adversary___NPC_Systems_2025-08-17.md

### 2025-08-17 standby_quiet_period_ack_Combat___Systems
decision: Combat   Systems acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Combat & Systems
files:
  - ops/reports/standby_ack_Combat___Systems_2025-08-17.md
=======
## 2025-08-17 — Decision
Context:
Standardize the Macro Manager nickname for brevity in inter-department messages.

Options:
1) No alias.
2) Adopt "McMa" as the recognized nickname.

Decision:
Adopt "McMa".

Rationale:
Short, unambiguous handle for Tech Support tasks and macro requests.

Impact:
Docs updated. Communications may address Macro Manager as "McMa".

Owner:
Macro Manager

Links:
- docs/macros.md
>>>>>>> 49e97cd4c14711c137dea920bd6020cd6c9a2f42

### 2025-08-17 standby_quiet_period_ack_Publishing_Studio
decision: Publishing Studio acknowledged Stand-by order.
context: Quiet Period active; notice pinned per lead; hotfix protocol ready.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: Publishing_Studio
files:
  - ops/reports/standby_ack_Publishing_Studio_2025-08-17.md

### 2025-08-17 standby_quiet_period_all_ack
decision: All departments acknowledged Stand-by order.
context: Quiet Period active across all offices.
owners: Stationmaster
logged_by: Postmaster (Mail)
scope: all offices
files:
  - ops/reports/standby_ack_status_2025-08-17.md

<<<<<<< HEAD
=======
## 2025-08-17 — Decision
Context:
Adopt a macro to suppress chat previews by standardizing the first line and moving content into a fenced block.

Options:
1) Do nothing; rely on author discipline.
2) Add `quiet-mail` macro to enforce format.

Decision:
Add `quiet-mail` to Macro Pack v0.1.

Rationale:
Consistent preview suppression across desktop and web without app settings.

Impact:
New macro available. Docs updated.

Owner:
Macro Manager (McMa)

Links:
- docs/macros.md

>>>>>>> 49e97cd4c14711c137dea920bd6020cd6c9a2f42
