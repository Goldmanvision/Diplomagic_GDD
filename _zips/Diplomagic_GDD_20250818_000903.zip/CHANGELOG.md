<<<<<<< HEAD
2025-08-17 | mail/global | Stand-by | A&R acknowledged | Scope=A&R
2025-08-17 | mail/global | Stand-by | QA & UX acknowledged | Scope=QA & UX
2025-08-17 | mail/global | Stand-by | Mail acknowledged | Scope=Mail
2025-08-17 | mail/global | Stand-by | Steam Operations acknowledged | Scope=Steam_Operations
2025-08-17 | mail/global | Stand-by | Narrative   Canon acknowledged | Scope=Narrative & Canon
2025-08-17 | mail/global | Stand-by | Adversary   NPC Systems acknowledged | Scope=Adversary & NPC_Systems
2025-08-17 | mail/global | Stand-by | Combat   Systems acknowledged | Scope=Combat & Systems
2025-08-17 | mail/global | Stand-by | Publishing Studio acknowledged | Scope=Publishing_Studio
2025-08-17 | mail/global | Stand-by | All offices acknowledged | Scope=all offices
=======
### 2025-08-17 09:15 ET
Changed:
- docs/macros.md — Maintainer line updated to include alias "McMa".
- docs/macros.md — Added Aliases note.

Added:
- DECISIONS entry formalizing "McMa" nickname.

Removed:
- none

Notes:
- Alias is workspace-scoped and documented for consistency.



### 2025-08-17 09:25 ET
Changed:
- docs/macros.md — Added `quiet-mail` macro docs.

Added:
- DECISIONS entry for `quiet-mail` adoption.

Removed:
- none

Notes:
- Macro outputs a leading sentinel line and fenced content.

>>>>>>> 49e97cd4c14711c137dea920bd6020cd6c9a2f42
