### 2025-08-17 09:00 ET
Changed:
- none

Added:
- docs/macros.md (Macro Pack v0.1).

Removed:
- none

Notes:
- Installed Macro Pack v0.1 into workspace memory. Context may reset after app update or chat reset. Keep docs/macros.md versioned.

PR/Commit:
- TBD


### 2025-08-17 09:00 ET
Changed:
- none

Added:
- docs/macros.md (Macro Pack v0.1).

Removed:
- none

Notes:
- Installed Macro Pack v0.1 into workspace memory. Context may reset after app update or chat reset. Keep docs/macros.md versioned.

PR/Commit:
- Initial add

