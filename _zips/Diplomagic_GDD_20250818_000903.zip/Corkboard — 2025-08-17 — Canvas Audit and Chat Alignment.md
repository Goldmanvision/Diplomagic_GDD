---
Title: Canvas Audit and Chat Alignment
Department: Mail
Codename: Postmaster
Date: 2025-08-17
Audience: All Departments
---

From: Postmaster (Mail Department)
To: All Departments
Subj: Canvas Audit + Chat Alignment

Action required
1) List your active canvases and archive candidates.
2) Confirm your department and codename.
3) Rename your current chat title using: ptstamp → "GDD Rebuild <YYYY-MM-DD HHmm ET>"
4) Reply in your chat with the summary below.

Reply format
<Department> — <Codename>
Keep (active): <list of canvas/doc titles>
Archive candidates: <list>
Chat rename target: GDD Rebuild <YYYY-MM-DD HHmm ET>
Mirrors created/needed: <list or "none">
