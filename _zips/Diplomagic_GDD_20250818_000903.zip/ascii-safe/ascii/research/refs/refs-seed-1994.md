---
Department: Authenticity & Research
Codename: Archivist
Date: 2025-08-17
Type: References
Status: Seed
---

# Seed References — 1994
Add authoritative sources only. Prefer primary sources and contemporaneous publications.

Placeholders
- DOJ/FBI procedural manuals (1993–1995)
- Consumer electronics catalogs (1993–1994)
- Newspaper archives for relevant events

## Primary Source 1
Title: Simon Says “Here’s How!” — User’s Manual  
Publisher: IBM Corp.  
Year: 1994  
Relevance: Baseline for PDA/phone UI and interactions used in DIPLOMAGIC.  
Added: 2025-08-17

## Primary Source 2
Title: Apple Newton MessagePad 110 — User’s Manual  
Publisher: Apple Computer, Inc.  
Year: 1994  
Relevance: Stylus UI, handwriting recognition workflows, and PDA interaction patterns contemporaneous with 1994 setting.  
Added: 2025-08-17


## Primary Source 3
Title: AT&T EO Personal Communicator — Owner’s Manual
Publisher: AT&T
Year: 1993
Relevance: Early pen-based PDA precedents for gestures, notepad UI, and mobile workflows immediately preceding 1994.
Added: 2025-08-17


## Primary Source 4
Title: FIPS PUB 185 — Escrowed Encryption Standard (EES)
Publisher: NIST
Year: 1994
Relevance: Defines 1994 U.S. crypto policy context (Clipper/LEAF) affecting communications, devices, and law-enforcement procedures in-setting.
Added: 2025-08-17


## Primary Source 5
Title: Radio Shack 1994 Annual Catalog
Publisher: Tandy Corporation
Year: 1994
Relevance: Consumer electronics specs and pricing for PDAs, modems, phones, and peripherals used in 1994 worldbuilding.
Added: 2025-08-17
