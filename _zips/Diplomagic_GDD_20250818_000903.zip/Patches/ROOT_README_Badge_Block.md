# README — Badge/Text Block (CH5–CH6)
Repo dir: /Patches

**Status:** CH5–CH6 root merge in review  
**Era Lock:** 1994 (MicroTAC, analog CCTV, Polaroids)  
**UI:** prompts ≤14 chars; **Blue‑on‑Blue** = fail  
**Scoring:** CH6 evidence cap 3; neutralizations score‑neutral  
**Phrase:** ambient only — “the stars are right tonight.”
