# GitHub Labels & Milestones — CH5–CH6 PR
Repo dir: /Patches

## Labels (apply to PR and issues)
- `area:narrative`
- `area:systems`
- `area:world`
- `area:ui`
- `qa`
- `period-1994`
- `prompt-≤14`
- `roe-raid`
- `blue-on-blue`
- `evidence-cap-3`

## Milestone
- `v0.6-ch5-6-merge`

## Project (optional)
- "DIPLOMAGIC — Root Integration" board

Notes: Ambient phrase only — “the stars are right tonight.”
