# PR — Term Glossary (CH5–CH6)
Repo dir: /Patches

- **D‑LAMP**: Abandoned deep lab network; WV shaft access.
- **Iron Highway**: Utility tunnel roadway for D‑LAMP rovers.
- **SRS Secret Annex**: Raid target under Savannah River Site.
- **Splinter of Azathoth**: Vault objective artifact.
- **Phrases**: Multi‑use spells; equip L/R.
- **Scrolls**: Single‑use spells in Inventory.
- **Blue‑on‑Blue**: Friendly‑fire fail condition.
- **Fast Travel**: Phrase from CH4 spellbook.
- **Ambient phrase**: “the stars are right tonight.” (ambient only)
- **MicroTAC**: Phone model; period‑correct.

Use these forms exactly across docs.
