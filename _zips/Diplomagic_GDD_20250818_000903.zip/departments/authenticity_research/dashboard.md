> Mirror path: /departments/authenticity_research/dashboard.md
> Source chat: GDD Rebuild 2025-08-17 — Authenticity & Research
> Last mirrored: 2025-08-17

# Authenticity & Research — Department Dashboard

## Keep
- /departments/authenticity_research/charter.md

## Planned
- /research/checks/period_check_core_terms_1994.md
- /research/refs/refs_seed_1994.md
- /research/glossary_1994.md

## Archive candidates
- None
