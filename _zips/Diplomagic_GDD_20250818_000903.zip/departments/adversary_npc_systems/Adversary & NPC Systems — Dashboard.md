---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: Dashboard
Status: Active
---

# Adversary & NPC Systems — Dashboard
Keep
- schema_statblock.md
- enemy_* statblocks
- spawn tables

Notes
- Use /data/statblocks and /data/spawn for assets.


## Archived (2025-08-17)
- [Statblocks & Enemies Department — Charter](/mnt/data/archive/adversary_npc_systems/Statblocks & Enemies Department — Charter (ARCHIVED 2025-08-17).md)
- [Enemy Systems Department — notes](/mnt/data/archive/adversary_npc_systems/Enemy Systems Department — notes (ARCHIVED 2025-08-17).md)
