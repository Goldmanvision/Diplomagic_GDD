
### main/
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git
https://github.com/Goldmanvision/Diplomagic_GDD

### .github
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\.github
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/.github

### .github/scripts
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\.github\scripts
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/.github/scripts

### .github/workflows
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\.github\workflows
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/.github/workflows

### .idea
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\.idea
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/.idea

### /Archive
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Archive
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Archive

### /Backups
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Backups
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Backups


### /Patches
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Patches
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Patches


### /Rules
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Rules
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Rules


### /Scripts
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Scripts
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Scripts


### /Steam
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Steam
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Steam


### /Trackers
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\Trackers
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/Trackers


### /developer_guides
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\developer_guides
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/developer_guides


### /reports
F:\Diplomagic_GDD_MASTER\Updated_GDD\Diplomagic_GDD_git\reports
https://github.com/Goldmanvision/Diplomagic_GDD/tree/main/reports