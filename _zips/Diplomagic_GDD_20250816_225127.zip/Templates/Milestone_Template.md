# Milestone: <title>

Date created: <YYYY-MM-DD> ET
Owner: <name>

Goal
- <single sentence goal>

Scope
- <bulleted list of included work>

Out of scope
- <bulleted list of excluded work>

Deliverables
- <files or artifacts expected>

Acceptance criteria
- <objective checks used to accept the milestone>

Risks
- <top risks>

Mitigations
- <how each risk is reduced>

Timeline
- Start: <YYYY-MM-DD>
- Code freeze: <YYYY-MM-DD>
- Merge/Ship: <YYYY-MM-DD>
- Post-merge validation: <YYYY-MM-DD>

Issue checklist
- [ ] <task 1>
- [ ] <task 2>
- [ ] <task 3>

Links
- <tracker and PR links>
