# Tracker — CH6 Flags and Endings
Repo dir: /Trackers

| Flag | Meaning |
|---|---|
| F_UCBriefed | UC pre-brief completed |
| F_SafehouseSting | Safehouse raid done |
| F_SRSBreach | SRS perimeter entered |
| F_CoreFound | Core Gallery located |
| F_RitualIgnited | Ritual started |
| F_End_Contain | Ending A: Seal |
| F_End_Escape | Ending B: Sever |
| F_End_BlackFile | Ending C: Black File |
| BlueOnBlue | 0=clean, 1=friendly-fire |
| EvidenceCount | CH6 evidence items (cap 3) |

Carryover: phrases L/R, Mana, scrolls.
