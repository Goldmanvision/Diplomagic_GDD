# Tracker — D‑LAMP Evidence Index (CH5→CH6)
Repo dir: /Trackers

## Provenance
- AEC→DOE exit memo (1970s copy) – establishes abandonment.
- Site re‑entry note (c. 1983) – padlock replacement log.
- Purchase orders (1986–1991) – reagents, braziers, rope, bells.
- Rota sheets (1988–1993) – “Order of the Splintered God.”
- Phone slips – calls matching Brightstar exchange.
- Iron Highway route cards – nightly movements.
- Worship ephemera – sigils, pin sketches, chant cards.

## Scoring
- CH5: Manifest/route card +2 (cap 1).  
- CH6: Evidence items +2 each (cap 3 total).

## Chain of custody
- Bag+tag numbers, clerk initials, FD‑302 reference.

## Notes
- Ambient phrase only: “the stars are right tonight.”
