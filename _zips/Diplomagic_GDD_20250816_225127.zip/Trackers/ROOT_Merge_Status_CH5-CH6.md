# Tracker — Root Merge Status (CH5–CH6)
Repo dir: /Trackers

| Area | Task | Owner | Status | Notes |
|---|---|---|---|---|
| Narrative | Replace CH5/CH6 in SEC-03 |  | ☐ |  |
| Systems | Append to SEC-05 |  | ☐ |  |
| World | Append to SEC-06 |  | ☐ |  |
| UI | Append to SEC-07 |  | ☐ |  |
| QA | Run Build Verification |  | ☐ |  |
| README | Insert ToC bullets |  | ☐ |  |
| Validation | Run grep/rg checks |  | ☐ |  |
| PR | Open with template |  | ☐ |  |
| Sign-off | Narrative/Systems/QA |  | ☐ |  |

Legend: ☐ pending, ☑ done.
