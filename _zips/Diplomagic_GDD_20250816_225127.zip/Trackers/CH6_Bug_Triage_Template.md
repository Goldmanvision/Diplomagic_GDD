# Tracker — CH6 Bug Triage Template
Repo dir: /Trackers

**ID:** CH6-____  
**Title:**  
**Build:**  
**Area:** (Deep D-LAMP / Iron Hwy / Annex / Vault)  
**Severity:** Blocker / Major / Minor / Trivial  
**Priority:** P0 / P1 / P2 / P3  
**Repro Rate:** (Always / Often / Rare / Unable)

## Steps
1)  
2)  
3)  

## Expected
-

## Actual
-

## Attachments
- Timecode(s)  
- Logs (if any)  
- Save/seed

## Notes
- Verify ROE, evidence cap, prompts ≤14, 1994 lock.
