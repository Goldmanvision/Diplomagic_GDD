## Archive Process Guide — 2025-08-16
- Location: developer_guides/Archive_Process_Guide.md
- GitHub: https://github.com/Goldmanvision/Diplomagic_GDD/blob/main/developer_guides/Archive_Process_Guide.md
- Summary: Step-by-step guide for exporting archived chats to timestamped Markdown, committing to repo, and restarting workflow in a fresh chat using macros (`exmdcb`, `ptstamp`, `kickoff`). Includes templates, git/PowerShell commands, and safety checks.
- Author: Assistant (automated)
- Date: 2025-08-16

