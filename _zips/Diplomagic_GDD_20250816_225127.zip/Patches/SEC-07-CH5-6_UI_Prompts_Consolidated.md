# SEC-07 — CH5–CH6 UI Prompts (Consolidated)
Repo dir: /Patches
All prompts ≤14 chars.

## Core
Answer, Call Back, Cooperate, Lawyer Up, Inspect, Bag, Tag, Note, Map

## Rogue Ops / Comms
Pager, Payphone

## Combat / Stealth
Aim, Fire, Reload, Holster, Crouch, Hide, Dodge, Shove, Cuff, Arrest

## Spells
Equip L, Equip R, Cast L, Cast R, Shield, Ward Jam, FastTravel

## Deep D-LAMP
Elevator, Descend, Pry Door, Lights, Headlights, Horn, Drive, Brake, Enter, Exit

## Iron Highway / SRS
Breach, Pretext, Stakeout, Valve A, Valve B, Valve C
