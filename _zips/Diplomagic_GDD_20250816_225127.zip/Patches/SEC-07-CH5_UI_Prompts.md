# SEC-07 — CH5 UI Prompts
Repo dir: /Patches

Prompts must be ≤14 characters.

## Core
Answer, Call Back, Cooperate, Lawyer Up, Inspect, Bag, Tag, Note, Map

## Hotel Escape
Pursue, Back Off, Cuff, Disarm, Door-Jam

## D-LAMP
Badge, Pretext, Stakeout, Search

## Betsy
Knock, Warrant, Breach, Hide, Dodge, Shove

## Spells
Equip L, Equip R, Cast L, Cast R, Shield, Ward Jam
