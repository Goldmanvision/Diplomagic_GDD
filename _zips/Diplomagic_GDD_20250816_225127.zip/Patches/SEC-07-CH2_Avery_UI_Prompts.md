## UI — CH2 Avery Prompts (SEC-07 addendum)

Prompts must be ≤14 characters.

- Badge
- Warrant
- Say Phrase
- Cuff
- Arrest
- Reload
- Holster
- Search
- Bag
- Tag
- Evidence
- Radio
- Map
- Fax 302
- Teletype
