## World — CH3 Addendum (SEC-06)

### Clara & Reddy Nodes
- **Kadath Sectors A–D:** Looping pine scrub; Forage/Water nodes; bivouac sites.
- **Pine Break Portal:** Two-way portal behind Brightstar; returns from building to forest only.
- **Brightstar Anchors:** Service Corridor, Office, Multipurpose Room; non-anchors scramble per entry.
- **Scavenger Ambush Site:** Clearing with wagon debris; cover objects for TK play.

### Avery Nodes
- **Condemned Brightstar:** Caution tape, plywood panels, dim interior; spectral patrol path.
- **Spectral Spawn Points:** Cold spots that trigger phase-only vulnerability windows.
- **Threshold Chase Route:** Forced path from Office → Service Corridor → Portal yard.

### Hazards & Interactables (1994)
- No weapon lights. Flashlight cones, payphone stubs, paper notices. Fire extinguishers, sand tables, mop buckets usable.
