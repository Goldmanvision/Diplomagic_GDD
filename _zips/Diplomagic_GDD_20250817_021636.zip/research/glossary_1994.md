---
Department: Authenticity & Research
Codename: Archivist
Date: 2025-08-17
Type: Glossary
Status: Draft
---

# Glossary — 1994
Term | Definition | Source
--- | --- | ---
