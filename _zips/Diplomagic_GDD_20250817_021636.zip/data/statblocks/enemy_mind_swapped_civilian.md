---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: Statblock
Status: Stub
---

# Enemy Mind Swapped Civilian
Placeholder stub. Populate per schema_statblock.md.
