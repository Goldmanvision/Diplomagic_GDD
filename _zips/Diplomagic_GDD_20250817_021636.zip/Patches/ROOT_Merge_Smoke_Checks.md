# Tracker — Merge Smoke Checks (CH5–CH6)
Repo dir: /Trackers

- [ ] SEC-03 shows full CH5 and CH6 replacements
- [ ] SEC-05 has Raid ROE, Blue‑on‑Blue rules, evidence cap 3, phrases/scrolls
- [ ] SEC-06 lists Deep D‑LAMP, Iron Highway, Annex route
- [ ] SEC-07 has ≤14 prompts with **Ward Jam**; HUD shows Evidence 0/3 + BlueOnBlue
- [ ] README/ToC updated
- [ ] Search shows no "StarTAC/smartphone/Wi‑Fi/Bluetooth/GPS/SMS/SIM/digital camera"
- [ ] Ambient phrase present only as text: “the stars are right tonight.”
- [ ] ASCII map linked and names match route list
