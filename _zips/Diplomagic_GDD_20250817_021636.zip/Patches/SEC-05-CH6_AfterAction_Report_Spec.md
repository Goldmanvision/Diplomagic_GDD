# SEC-05 — CH6 After-Action Report (1994)
Repo dir: /Patches

## Documents
- **FD-302:** raid narrative, times, locations, personnel, use of force (raid ROE).  
- **Seizure Forms:** evidence numbers, chain of custody.  
- **Teletype (BOLO/INFO):** minimal facts to field offices.  
- **Debrief Notes:** Krill pager references, payphone logs.

## Process
1) Draft FD-302 from FieldPad notes (offline).  
2) Queue teletype and scans; upload only from NYFO.  
3) File seizure forms with Aiken Co. SO copy if joint.  
4) Evidence cap reminder: 3 items scored; extra may exist but do not alter score.

## Scoring Hook
- +2 each scored evidence (cap 3).  
- Endings bonuses per `CH6_Scoring_Raid.md`.  
- Blue-on-Blue = mission fail regardless of paperwork.

## UI prompts (≤14 chars)
Fax 302, Teletype, File, Bag, Tag, Note, Map
