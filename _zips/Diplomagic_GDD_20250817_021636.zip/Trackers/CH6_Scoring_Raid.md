# Tracker — CH6 Scoring (Raid)
Repo dir: /Trackers

| Action | Points |
|---|---:|
| Seal breach | +5 |
| Sever link | +3 |
| Black file | +5 evidence / −5 rep |
| Evidence item (cap 3) | +2 each |
| Blue-on-Blue | −10 and mission fail |

Notes: Hostile neutralization = 0 (no penalty, no bonus).
