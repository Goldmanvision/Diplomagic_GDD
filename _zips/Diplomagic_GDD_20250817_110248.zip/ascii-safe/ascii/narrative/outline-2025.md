---
Department: Narrative & Canon
Codename: Storymaster
Type: Mirror
Source: /mnt/data/Diplomagic Outline 2025.pdf
Last-Mirrored: 2025-08-17
Source-Bytes: 194957
Source-MD5: 0fb4c07457ced7a6a9978664b2eb3d98
Source-Pages: 19
Edit Policy: Do not edit. Update the source PDF.
---


# Mirror Index
Canonical source stored as PDF. This mirror tracks metadata, placement, and cross-links only.

## Cross-links
- Authenticity & Research: research/refs/refs-seed-1994.md
- Authenticity & Research: research/checks/period-check-core-terms-1994.md
- Authenticity & Research: research/glossary-1994.md

## Change log
- 2025-08-17: Metadata refresh.
