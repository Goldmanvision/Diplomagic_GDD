---
Title: Patch Proposal
Author: Postmaster
Date: 2025-08-17
Target: <path to .md>
Type: Patch
Status: Draft
---

# Rationale
<why>

# Proposed changes
<bullet list or small diff>

# Impacts
- Dependencies:
- Risks:
- Rollback:
