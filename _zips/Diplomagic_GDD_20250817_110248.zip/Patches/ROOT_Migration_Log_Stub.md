# Root Migration Log — CH5–CH6
Repo dir: /Patches

| Date | Author | File | Change | Notes |
|---|---|---|---|---|
| ____ | ____ | SEC-03-NARRATIVE - Narrative.md | Replace CH5/CH6 | Rogue pivot; Annex raid |
| ____ | ____ | SEC-05-SYSTEMS - Systems & Mechanics.md | Append ROE, AI, tuning | BlueOnBlue fail |
| ____ | ____ | SEC-06-WORLD - World, Levels, & Content.md | Add nodes/maps | Deep D-LAMP, Annex |
| ____ | ____ | SEC-07-UI - UI-UX (Devices, HUD, Menus).md | Merge prompts/flows | ≤14 chars |
| ____ | ____ | README/ToC | Update module links | Add CH5–CH6 |
