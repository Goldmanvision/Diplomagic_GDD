# ROOT_SEC-07_UI_Prompts_Master.md
> All prompts ≤14 characters. Keep 1994 tone. No emoji.

# Core
- Ward Jam
- Cast L
- Cast R
- Equip L
- Equip R
- Valve A
- Valve B
- Valve C
- Plant
- Detonate
- Photo
- Sample

# Combat
- Aim
- Fire
- Reload
- Swap Mag
- Melee
- Sprint
- Crouch
- Peek
- Dodge

# Interact
- Interact
- Inspect
- Open
- Close
- Lockpick
- Pry
- Breach
- Climb
- Jump

# Tools
- Radio
- Pager
- Map
- Notes
- FieldPad
- MEDSTAT
- Trunk

# Vehicle
- Start
- Park
- Exit
