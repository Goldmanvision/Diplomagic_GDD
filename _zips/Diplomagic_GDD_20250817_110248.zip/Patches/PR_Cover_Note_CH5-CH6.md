# PR Cover Note — CH5–CH6 Root Merge
Repo dir: /Patches

Team,
This PR integrates CH5–CH6 across Narrative/Systems/World/UI. Non‑negotiables: 1994 period, prompts ≤14, ambient phrase only (“the stars are right tonight”), CH6 raid ROE with Blue‑on‑Blue fail, evidence cap 3. Please review using the Validation Master Checklist and E2E script. Attachments and ASCII map linked in the PR body.
