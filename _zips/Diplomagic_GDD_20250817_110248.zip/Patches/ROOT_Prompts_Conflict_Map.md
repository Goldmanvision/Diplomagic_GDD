# Root — Prompts Conflict Map (≤14 chars)
Repo dir: /Patches

Replace any left column entry with the approved right column.

| Replace | Use |
|---|---|
| Place Explosive | Plant |
| Detonate Charge | Detonate |
| Call Krill Now | Call Back |
| Use Pay Phone | Payphone |
| Turn On Lights | Lights |
| Headlights On | Headlights |
| Open Door | Enter |
| Start Car | Drive |
| Take Photo | Photo |
| Take Sample | Sample |
| Disrupt Ward | Ward Jam |
| Ward Disruptor | Ward Jam |
| Equip Left Hand | Equip L |
| Equip Right Hand | Equip R |
| Cast Left | Cast L |
| Cast Right | Cast R |
| Use Elevator | Elevator |
| Crouch Down | Crouch |
| Hide Yourself | Hide |
| Suppressive Fire | Suppress |
| Throw Grenade | Frag |
| Show Map | Map |
| Write Note | Note |
| Talk | Answer |
| Call Back Now | Call Back |

Constraints: 1994 period; ambient phrase only — “the stars are right tonight.”
