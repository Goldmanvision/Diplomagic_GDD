# SEC-05 — CH6 Loadout Guide (1994)
Repo dir: /Patches

## Avery
- **Primary:** SIG P226 (9mm) or S&W 13 (.38).  
- **Backup:** 2 speedloaders / 2 mags.  
- **Grenades:** 2 frags if issued.  
- **Phrases (L/R):** Shield, Ward Jam.  
- **Scrolls:** 1× Plant (if available), 1× Sample (optional).  
- **Tools:** Polaroid, tape, valve tags, flashlight.

## Clara
- **Primary:** shotgun (slug) or carbine if available.  
- **Phrases (L/R):** Shield or Quiet Step.  
- **Scrolls:** 1× Photo, 1× Sample (Black File path).

## Reddy
- **Phrases:** TK Push, Shield.  
- **Limiters:** Mana only in calm windows.  
- **Role:** Stagger gaunts, cover valve/charge windows.

## Shared
- **Tonics:** 1–2 total.  
- **Med:** 2 first‑aid.  
- **Ammo:** respect CH6 tuning table.  
- **Evidence cap:** 3 items max.
