# Corkboard Snapshot — Narrative & Canon : Storymaster — Ops Thread 1

```
[Corkboard v2]
title: Acknowledge Department Charter — Narrative & Canon
channel: #dept-narrative-canon
link: /department_charters_pack.md

content:
Please reply ACK to confirm your charter and dashboard.
Canonical paths are ASCII-safe.
1994/1989 accuracy enforced.
Double-Confirm protocol applies.
```
