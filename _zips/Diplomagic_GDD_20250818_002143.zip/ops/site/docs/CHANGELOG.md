# CHANGELOG
## 2025-08-17
Updated
- data/spawn/spawn_tables_prologue_ch1.md — remove Prologue spectral-full; add branch coverage and failstates; SG notes.
- narrative/reports/ch1_pacing_vs_spawns_20250819.md — add sources, period checks, SE tallies, seeds→payoffs, UI strings/controls, sign-offs.
Created
- departments/adversary-npc-systems/verification/spawn-scene-bindings-notes-20250819.md — scene_id bindings and spectral caps.
## 2025-08-17
Updated
- research/refs/refs_seed_1994.md — add citations/links; PD notes; sign-off.

Created
- research/refs/scans/README.md — scans directory guide and naming rules.
