ptcork v2
title: Mail rollover
channel: #ops
content: Mail is moving to “Postmaster — Ops Thread 2” due to log size. Old thread enters naptime. All routing and logs continue in the new thread. Double-Confirm remains for multi-file batches.
link: /DECISIONS.md
---
