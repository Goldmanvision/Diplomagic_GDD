﻿ptcork v2
title: Handoff Validator task ended
channel: #ops
content: The scheduled new-commits + handoff checklist scan is shut down due to environment/auth limits. Mail will run validation on demand when requested by Suit. See DECISIONS.md for rationale.
link: /DECISIONS.md
---
