Merge fix/ch2-compliance

- Enforce CH2 compliance rules
- Add CH6 raid rules and CH7 city rules fixes
- Update evidence-cap values and validation tests
- See ARCHIVE_PACK: GDD Rebuild 2025-08-16 for context.
