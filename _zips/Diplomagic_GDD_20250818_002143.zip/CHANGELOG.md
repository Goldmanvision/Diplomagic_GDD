### 2025-08-17 09:15 ET
Changed:
- docs/macros.md — Maintainer line updated to include alias "McMa".
- docs/macros.md — Added Aliases note.

Added:
- DECISIONS entry formalizing "McMa" nickname.

Removed:
- none

Notes:
- Alias is workspace-scoped and documented for consistency.



### 2025-08-17 09:25 ET
Changed:
- docs/macros.md — Added `quiet-mail` macro docs.

Added:
- DECISIONS entry for `quiet-mail` adoption.

Removed:
- none

Notes:
- Macro outputs a leading sentinel line and fenced content.

