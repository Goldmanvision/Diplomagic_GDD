# Root — UI Wireflows (Text) for CH6
Repo dir: /Patches

All prompts ≤14 chars. 1994 period. Ambient phrase only: “the stars are right tonight.”

## HUD
Health | Stamina | Mana | Ammo | Evidence 0/3 | BlueOnBlue (off→fail)

## Valve Loop (Contain)
Near Valve A → **Valve A** → metal groan SFX → prompt clears → move to Valve B → **Valve B** → move to Valve C → **Valve C** → **Shield**/**Ward Jam** window → **STABLE** gimbal set.

## Charge Loop (Sever)
Coupling → **Plant** → Coupling 2 → **Plant** → Chant spikes → **Suppress** or **Cast L/R** to interrupt → **Detonate** (2 s fuse) → sprint markers light route.

## Evidence Loop (Black File)
Pylon panel → **Photo** → Gimbal plate → **Photo** → Reagent shelf → **Sample** → Bag/tag if needed → Evidence counter enforces 3/3 → “Cap Reached” if exceeding.

## Comms (Rogue)
Pager alert → **Pager** → nearest payphone → **Payphone** → timed call ≤90 s.

## Failure
Friendly hit → BlueOnBlue icon flash → fail screen.
