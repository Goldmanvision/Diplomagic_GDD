# ROOT — UI Copy Snippets (CH5–CH6, ≤14 chars)
Repo dir: /Patches

Use these exact labels. 1994 lock. Ambient phrase only: “the stars are right tonight.”

## Core
Answer • Call Back • Inspect • Bag • Tag • Note • Map • Exit • Descend

## Comms (Rogue)
Pager • Payphone

## Traversal
Elevator • Enter • Drive • Brake • Lights • Breach • Crouch • Hide • Dodge

## Combat
Aim • Fire • Reload • Suppress • Frag • Shove • Shield

## Spells
Equip L • Equip R • Cast L • Cast R • Ward Jam

## Annex tasks
Valve A • Valve B • Valve C • Plant • Detonate • Photo • Sample

## System alerts (short)
Cap Reached • BlueOnBlue • STABLE

## Do NOT use (too long)
“Call Krill Now” → use “Call Back”  
“Ward Disruptor” → use “Ward Jam”  
“Place Explosive” → use “Plant”
