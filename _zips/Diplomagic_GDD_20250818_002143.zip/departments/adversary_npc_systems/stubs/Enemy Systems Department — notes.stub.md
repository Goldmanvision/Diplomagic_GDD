---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: Stub
Replaced-By: /mnt/data/archive/adversary_npc_systems/Enemy Systems Department — notes (ARCHIVED 2025-08-17).md
---

# Stub: Enemy Systems Department — notes
This document was archived on 2025-08-17. Refer to:
- Archive: /mnt/data/archive/adversary_npc_systems/Enemy Systems Department — notes (ARCHIVED 2025-08-17).md
- Current sources: /departments/adversary_npc_systems/Adversary & NPC Systems — Dashboard.md and /data/statblocks/schema-statblock.md
