# SEC-03 — CH6 Epilogue
Repo dir: /Patches

## Overview
Final outcomes after the SRS raid. No civilians present. Phrase remains ambient: “the stars are right tonight.”

### Ending A — Contain (Seal)
- **Public face:** minor incident, localized blackout.  
- **Internal:** commendations in sealed annex; Krill message: “not over.”  
- **Hooks:** legal pressure on D‑LAMP vendors; Clara/Reddy low profile.  
- **Slides:** injured saved count; splinter stabilized.

### Ending B — Sever (Escape)
- **Public face:** unexplained anomalies near fence line; whispers.  
- **Internal:** reprimand avoided; Krill prioritizes damage control.  
- **Hooks:** rogue cells scatter; Iron Highway collapse risks.  
- **Slides:** team intact; area warped.

### Ending C — Black File (Evidence-first)
- **Public face:** nothing on record.  
- **Internal:** evidence maximum; reputation hit logged.  
- **Hooks:** secret indictments; Krill warns of fallout.  
- **Slides:** dossiers filled; trust eroded.

## Postcards (optional stingers)
- Clara & Reddy: roadside diner, 3 a.m., pager buzz.  
- Avery: MicroTAC rings from an unknown exchange.  
- Deputy {DeputyName}: radio silence, then a single horn-call on scan.
