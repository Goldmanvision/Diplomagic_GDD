## World — CH2 Avery: Inner Checkpoint (SEC-06 addendum)

### Nodes
- Outer Fence: low light, chain-link, single patroller.
- Inner Gate (Checkpoint): challenge/response node; passphrase gate.
- Outbuilding A: cash ledger + rosters.
- Shed B: generator; optional power cut branch.
- Office Shack: microcassettes + gate logbook; fax/teletype access for later use (secure line at SO).

### Patrols (1994 lighting)
- Two-guard loop on 90s arcs. Flashlight cones only. No NVGs.
- Civilian path near Office Shack; avoid collateral.

### Evidence Placement
- Ledger in lockbox (simple pin tumbler).
- Rosters on clipboard.
- Tapes in desk drawer.
- .38 on Deacon analogue.

### Exit
- Exfil via Outer Fence rendezvous with {DeputyName}. Booking at Aiken Co. SO.
