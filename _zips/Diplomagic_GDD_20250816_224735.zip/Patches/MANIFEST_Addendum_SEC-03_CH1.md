# MANIFEST addendum — SEC-03 CH1 synopsis
Date: 2025-08-14 22:50:08 UTC

Section: SEC-03-NARRATIVE
Change:
- Add §3.5 “Chapter 1 — Simple Curiosity” using `Patches/SEC-03_3.5_CH1_SimpleCuriosity_ADD.md`.

Version bump:
- SEC-03 minor +1

Cross-refs:
- Trackers/CH1_Outline_SimpleCuriosity.md
- Trackers/CH1_Beat2Objective.md
- Trackers/AssetList_CH1_Brightstar.md
- Trackers/QATelemetry_CH1.md
