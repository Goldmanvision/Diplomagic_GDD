# SEC-07 — CH6 Raid UI Prompts
Repo dir: /Patches

All prompts ≤14 chars.

## Core Combat
Aim, Fire, Reload, Holster, Suppress, Frag

## Movement / Stealth
Crouch, Hide, Dodge, Shove, Breach

## Spells
Equip L, Equip R, Cast L, Cast R, Shield, Ward Jam

## Ops / Map
Map, Note

## Annex Tasks
Valve A, Valve B, Valve C
