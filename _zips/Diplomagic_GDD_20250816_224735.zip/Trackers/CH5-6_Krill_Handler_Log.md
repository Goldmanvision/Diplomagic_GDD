# Tracker — Krill Handler Log (CH5→CH6)
Repo dir: /Trackers

| Time | Code | Node | Note |
|---|---|---|---|
| __:__ | 911 | Pager | Contact now |
| __:__ | 77 | Payphone | Abort route |
| __:__ | 23 | Payphone | Reroute to Safe Node |
| __:__ | 19 | Payphone | Evidence upload next NYFO |

Flags: `F_Rogue`, `F_KrillHandler`, `F_HandlerLost`.
Safe Nodes: NYC hotel booth, D‑LAMP island call box, diner near SRS.
