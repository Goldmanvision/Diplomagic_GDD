# Issue Template — CH5–CH6 Root Merge
Repo dir: /Trackers

**Title:** [Area] Short description

**Area:** Narrative / Systems / World / UI / Audio / QA

**File(s):**

**Problem:**
-

**Expected (per patch):**
-

**Repro steps:**
1)
2)
3)

**Constraints check:**
- [ ] 1994 lock
- [ ] Prompts ≤14
- [ ] Ambient phrase only (“the stars are right tonight”)
- [ ] CH6 ROE: lethal authorized; Blue‑on‑Blue fail
- [ ] Evidence cap 3 (CH6)

**Attachments:** (optional)
