# SEC-03 — CH6 Narrative Addendum: Raid ROE
Repo dir: /Patches

- CH6 reframed as a sanctioned **raid** on hostile combatants (Sovereign Nation of New Kadath / Order of the Splintered God).  
- **Lethal force authorized**. Neutralizations are **score-neutral**.  
- **Blue-on-blue** is a hard fail (−10 and abort).  
- Evidence bonuses remain capped at **3 items**.  
- Civilians not present in AO; if design changes, disengage and mark.
