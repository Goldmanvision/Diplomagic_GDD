# Review Sign‑off Sheet — CH5–CH6 Root Merge
Repo dir: /Trackers
Date: 2025-08-15

- [ ] Narrative Lead — name/date
- [ ] Systems Lead — name/date
- [ ] World Lead — name/date
- [ ] UI Lead — name/date
- [ ] Audio Lead — name/date
- [ ] QA Lead — name/date

Confirm:
- [ ] 1994 period lock
- [ ] Prompts ≤14
- [ ] Ambient phrase only (“the stars are right tonight”)
- [ ] CH6 raid ROE with Blue‑on‑Blue fail
- [ ] Evidence cap 3
