---
Department: Adversary & NPC Systems
Codename: Taxonomist
Date: 2025-08-17
Type: Stub
Replaced-By: /mnt/data/archive/adversary_npc_systems/Statblocks & Enemies Department — Charter (ARCHIVED 2025-08-17).md
---

# Stub: Statblocks & Enemies Department — Charter
This document was archived on 2025-08-17. Refer to:
- Archive: /mnt/data/archive/adversary_npc_systems/Statblocks & Enemies Department — Charter (ARCHIVED 2025-08-17).md
- Current sources: /departments/adversary_npc_systems/Adversary & NPC Systems — Dashboard.md and /data/statblocks/schema_statblock.md
