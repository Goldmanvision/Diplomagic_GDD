---
Department: Steam Operations
Codename: Stationmaster
Date: 2025-08-17
Type: Charter
Status: Draft
---

# Steam Operations — Charter (2025-08-17)
Scope: store page, builds, backend config, pricing, regionalization, compliance.
Outputs: .md only.
