# Tracker — CH6 Playtest Log Sheet
Repo dir: /Trackers

| Tester | Date | Ending | Evidence (0–3) | BlueOnBlue | Deaths | Ammo Used P/S/R | Tonics | Notes |
|---|---|---|---:|---|---:|---|---:|---|
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |

Notes: Use 1994 terminology. No screenshots required.
