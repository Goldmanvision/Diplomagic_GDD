# PR Reviewer Assignment Matrix — CH5–CH6
Repo dir: /Trackers

| Area | Primary | Backup | Notes |
|---|---|---|---|
| Narrative | ______ | ______ | CH5/CH6 replacement |
| Systems | ______ | ______ | ROE, phrases/scrolls, scoring |
| World | ______ | ______ | D‑LAMP, Iron Hwy, Annex nodes |
| UI | ______ | ______ | ≤14 prompts, HUD Evidence/BlueOnBlue |
| Audio | ______ | ______ | Valves/charges/chants cues |
| QA | ______ | ______ | E2E paths, evidence cap, Blue‑on‑Blue |

Constraints: 1994 lock; ambient phrase “the stars are right tonight.”
