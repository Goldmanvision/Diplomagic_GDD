# Tracker — CH6: Savannah River
Version: v0.1 • 2025-08-15
Repo dir: /Trackers

| Field | Value |
|---|---|
| UC Briefed | F_UCBriefed |
| Safehouse Sting | F_SafehouseSting |
| SRS Breach | F_SRSBreach |
| Core Found | F_CoreFound |
| Ritual Ignited | F_RitualIgnited |
| Ending | F_End_Contain / F_End_Escape / F_End_BlackFile |
| Evidence | Ledgers, Reagents, SRS Maps (cap 3), Polaroids, FD‑302 |
| ROE | Raid — Lethal Authorized; BlueOnBlue monitored |
| Spells | Phrases equip L/R; Mana; Scrolls single‑use |
| UI ≤14 | Badge, Pretext, Breach, Hide, Dodge, Shove, Cuff, Arrest, Search, Bag, Tag, Equip L, Equip R, Cast L, Cast R, Shield, Ward Jam, Map, Note |

BlueOnBlue: 0 → flip to 1 on friendly-fire.
