---
Department: Narrative & Canon
Codename: Storymaster
Date: 2025-08-17
Type: Mirror
Source: /mnt/data/Diplomagic Outline 2025.pdf
Edit Policy: Do not edit. Update the source PDF.
Status: Mirrored
---

# Diplomagic Outline 2025 — Mirror
This file indexes the canonical PDF and tracks placement only.
