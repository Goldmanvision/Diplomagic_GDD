# SEC-06 — CH5→CH6 Callsigns & Nodes
Repo dir: /Patches

## Callsigns (radio/pager codes)
- **LEAD:** Avery  
- **SAGE:** Clara  
- **DRIFT:** Reddy  
- **ANCHOR:** {DeputyName}  
- **HAND:** Krill (pager only)

## Sites (codenames)
- **DEEP-GLASS:** D‑LAMP deep site  
- **IRON-MILE:** Iron Highway  
- **ANNEX-GATE:** SRS bulkhead layby  
- **VALVE-ROW:** valve corridor  
- **VAULT-RING:** Splinter catwalk ring

## Quick-use UI prompts (≤14)
LEAD, SAGE, DRIFT, ANCHOR, HAND (labels only)
